import { TestBed } from '@angular/core/testing';

import { Materialcovid19SService } from './materialcovid19-s.service';

describe('Materialcovid19SService', () => {
  let service: Materialcovid19SService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(Materialcovid19SService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
